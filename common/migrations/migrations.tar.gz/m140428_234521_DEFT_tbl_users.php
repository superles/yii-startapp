<?php

class m140428_234521_DEFT_tbl_users extends CDbMigration
{
	public function up()
	{
	$this->createTable("tbl_users", array(
    "id"=>"int(11) NOT NULL AUTO_INCREMENT",
    "username"=>"varchar(50) NOT NULL",
    "email"=>"varchar(100) NOT NULL",
    "password"=>"varchar(100) NOT NULL",
    "firstname"=>"varchar(32)",
    "lastname"=>"varchar(32)",
    "role_code"=>"enum('admin','user') NOT NULL DEFAULT 'user'",
    "created_at"=>"timestamp",
    "updated_at"=>"timestamp",
    "dt_last_login"=>"datetime",
    "dt_expiry"=>"datetime NOT NULL",
    "count_logins"=>"int(11) unsigned NOT NULL DEFAULT '0'",
    "status"=>"tinyint(4)",
    "verify_string"=>"varchar(50) NOT NULL",
    "verify_email"=>"varchar(50) NOT NULL",
    "verified"=>"tinyint(4)",
"PRIMARY KEY (id)"), " DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci");


	}

	public function down()
	{
		echo "m140428_234521_DEFT_tbl_users does not support migration down.\n";
		return false;
	}

	/*
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
	}

	public function safeDown()
	{
	}
	*/
}